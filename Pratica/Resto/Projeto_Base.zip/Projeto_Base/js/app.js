import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

// 1. Criar Scene
// 2. Criar Camera
// 3. Criar Renderer
// 4. Criar um cubo
// 5. Adicionar o cubo à Scene
// 6. Criar função animar()
// 7. Adicionar esfera e cone
// 8. Implementar os botões
